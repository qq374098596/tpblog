<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"/home/ftp/6/68982/wwwroot/public/../application/index/view/index/index.html";i:1520517377;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	1111
</body>
</html>