<?php

difine('APP_PATH', __DIR__ . '/../application/');

require __DIR__ . '/../thinkphp/start.php';
?>